// Internationalization
// author: huaxiangchun 00189548 2014-03-18
// Copyright © Huawei Technologies Co., Ltd. 2014. All rights reserved.

// namespace
var I18N = {};

// module name 
I18N.Module = {
	Teller:'Teller',
	Terminal:'Terminal',
	Vtmctl:'Vtmctl'
};

I18N.Language = {
	zh : 'zh',
	en : 'en'
}

// International utils
I18N.utils = 
{
	_first: true,
	_language: 'en',
	_resource:{},
	// !function
	// desc：international
	// params：
	// [IN] navigator : navigator object
	// [IN] document : document object
	// [IN] pageName : page name. "Terminal","Teller","Vtmctl"
	// return： void
	parseI18N: function(navigator, document, pageName)
	{
		if (this._isNull(navigator) || this._isNull(document) || this._isNull(pageName) )
		{
			return;
		}
		var lang = navigator.language || navigator.userLanguage || navigator.browserLanguage;
		if (this._isNull(lang) || lang.indexOf('zh')<0)
		{
			return;
		}

		this.switchI18N(document, pageName, 'zh');
	},
	// !function
	// desc：international
	// params：
	// [IN] navigator : navigator object
	// [IN] document : document object
	// [IN] pageName : page name. "Terminal","Teller","Vtmctl"
	// return： void
	switchI18N: function(document, pageName, language)
	{
		if (this._isNull(document) || this._isNull(pageName) || this._isNull(language) )
		{
			return;
		}
		if ('zh'!=language && 'en'!=language)
		{
			return;
		}
		if (this._language == language)
		{
			return;
		}
		
		if ('en'==language )
		{
			pageName = language;
		}
		
		// parse h2
		this._parseByTagName(document, pageName, 'h2');
		// parse h3
		this._parseByTagName(document, pageName, 'h3');
		// parse td
		this._parseByTagName(document, pageName, 'td');
		// parse span
		this._parseByTagName(document, pageName, 'span');
		// parse option
		this._parseByTagName(document, pageName, 'option');
		// parse li
		this._parseByTagName(document, pageName, 'li');
		// parse input
		this._parseByTagName(document, pageName, 'input');
		// parse p
		this._parseByTagName(document, pageName, 'p');
		// parse a
		this._parseByTagName(document, pageName, 'a');
		
		this._language = language;
		
		if('zh'==language && this._first)
		{
			this._first = false;
		}
	},
	// !function
	// desc：international
	// params：
	// [IN] document : document object
	// [IN] pageName : page name. "Terminal","Teller","Vtmctl"
	// [IN] tagName : tag name. 
	// return： void
	_parseByTagName: function(document, pageName, tagName)
	{
		if (null==document || null==pageName || null==tagName)
		{
			return;
		}
		var _elems = null;
		try
		{
			_elems = document.getElementsByTagName(tagName);
		}catch(e) {return;}
		
		if (null==_elems || 0==_elems.length)
		{
			return;
		}
		
		var _resource = ('en'==pageName)? this._resource : I18N[pageName];
		if (null==_resource || undefined==_resource || {}==_resource)
		{
			return;
		}
		
		for (var i=0;i<_elems.length;++i)
		{
			var _ele = _elems[i];
			var _att = _ele.getAttribute('self');
			if (null==_att || undefined==_att)
			{
				continue;
			}
			var _value = _resource[_att];
			if (this._isNull(_value) )
			{
				continue;
			}
			
			if (this._first)
			{
				this._resource[_att]= ('input'==tagName)? _ele.value : _ele.innerHTML;
			}
			('input'==tagName)? (_ele.value=_value):(_ele.innerHTML=_value);
		}
		
		return;
	},
	// !function
	// desc：whether the object exists
	// params：
	// [IN] obj : object
	// return： bool
	_isNull: function(obj)
	{
		if(null==obj || undefined==obj)
		{
			return true;
		}
		return false;
	}
};