// Agent Ocx
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

function GetLanguagePageString(LanguagePageItem){
	var LanguagePage = new LanguagePageClass();
	var I18N = new I18NClass();
	var languageObj = null;
	languageObj = LanguagePage.GetLanguagePage(Config.Common['Language'])
	if (languageObj === null || languageObj === undefined){
		return LanguagePageItem;
	}
	if (languageObj[LanguagePageItem] === null ||　languageObj[LanguagePageItem] === undefined){
		return LanguagePageItem;
	}
	return languageObj[LanguagePageItem];
}
var Agent = function()
{
	this._ocx = null;; //ocx object
	// !function whether ocx is null(private function)
	this._isNull = function()
	{
		return (null===this._ocx || undefined===this._ocx);
	}
}

Agent.prototype = {

    // !function init Agent
    init: function (ocxId) {
        this._ocx = document.getElementById(ocxId);

        //SetBtnStatus("signout");
        AgentUI.UpdateAgentStatus();
        AgentUI.UpdateCallStatus();
    },

    Register: function (PhoneNumber, PhonePwd) {
        return VoiceExcute("Register", PhoneNumber, PhonePwd, 0);
    },

    // !function SignInEx
    SignInEx: function (WorkNo, AgentPwd, ProgID, PhoneNumber) {
        if (this._isNull()) {
            return null;
        }

        var _return;

        this._ocx.MainCcsIP = Config.Agent.MainCcsIP;
		this._ocx.BackCcsIP = Config.Agent.BackCcsIP;
        this._ocx.CcsID = Config.Agent.CcsID;
        this._ocx.AgentType = 4;// pc phone
        this._ocx.WorkNo = WorkNo;
        this._ocx.Password = AgentPwd;
        this._ocx.AutoAnswer = Config.Agent.AutoAnswer;
        this._ocx.AutoRelease = 1;// auto release
        this._ocx.MyID = ProgID;

        //initial
        _return = this._ocx.Initial();

        if (_return !== 0) {
			//returning 131 indicates that the agent has logged in, promote to force login
			if (_return === 131){
				
				var r=confirm(GetLanguagePageString("I18N_AGENTAPPDEMO_PROMOTE_FORCE_LOGIN"));
				if (r===true){
					INFO_LOG_METHOD("AgentOcx", "Agent choose to force sign in");
					_return = this._ocx.InitialEx();
					if (_return !== 0) {
						INFO_LOG_METHOD("AgentOcx", "Interface:Initial, error.result:" + _return);
						return ;
					}
				}
				else {
					INFO_LOG_METHOD("AgentOcx", "Agent canceled force sign in");
					INFO_LOG_METHOD("AgentOcx", "Interface:Initial, error.result:" + _return);
					return ;
				}
			}
			else{
				INFO_LOG_METHOD("AgentOcx", "Interface:Initial, error.result:" + _return);
				return _return;
			}
        }
		//if sign in enter work, first change status to study, to avoid call in before say busy
		if (Config.Agent.SignInEnterWork){
			this._ocx.ChangeAgentStatus(8, 1, 0);//8 indicates study status
		}
        _return = this._ocx.SignInEx('TTF', AgentOcx._ocx.AgentType, PhoneNumber);

        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:SignInEx, error.result:" + _return);
            return _return;
        }
		//if sign in enter work, second change status to busy
		if (Config.Agent.SignInEnterWork){
			this._ocx.AgentEnterWork();
			this._ocx.ChangeAgentStatus(8, 0, 0);//8 indicates study status
		}
        return this._ocx.SetAgentAutoEnterIdle(Config.Agent.AutoEnterIdle);
    },

    // !function SignOutEx
    SignOutEx: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.SignOutEx();
    },

    // !function SayBusy
    SayBusy: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.SayBusy();
    },
	SayBusyWithReason: function(busyReason){
		if (this._isNull()) {
            return null;
        }

        return this._ocx.SayBusyWithReason(busyReason);
	},
    // !function SayFree
    SayFree: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.SayFree();
    },

    // !function AgentEnterWork
    AgentEnterWork: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.AgentEnterWork();
    },

    // !function AgentEnterIdle
    AgentEnterIdle: function () {
        if (this._isNull()) {
            return null;
        }

        var _return = this._ocx.AgentEnterIdle();


        return _return;
    },

    // !function RestEx
    RestEx: function (restTime, restCause) {
        if (this._isNull()) {
            return null;
        }
        // RestEx(RestDuration,RestCause)
        return this._ocx.RestEx(restTime, restCause);
    },

    // !function RestEx
    Rest: function (restTime) {
        if (this._isNull()) {
            return null;
        }
        // RestEx(RestDuration,RestCause)
        return this._ocx.Rest(restTime);
    },

    // !function CancelRest
    CancelRest: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.CancelRest();
    },

    // !function AnswerEx
    AnswerEx: function (usMediaType) {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.AnswerEx(usMediaType);
    },

    // !function ReleaseCallEx
    ReleaseCallEx: function (usMediaType, usCCBIdx) {
        if (this._isNull()) {
            return null;
        }

        if (parseInt(usMediaType) === 1)//webchat mediatype is 1
		{
			INFO_LOG_METHOD("AgentOcx","Release webchat ccbidx="+usCCBIdx);
			return this._ocx.ReleaseCallExWithCCBIdx(usMediaType, usCCBIdx);
		}
        INFO_LOG_METHOD("AgentOcx","Release mediatype=" + usMediaType);
	//if media type is 2 or 5 
	return this._ocx.ReleaseCallExWithCCBIdx(5, 1);
    },

    // !function BeginMuteUserEx
    BeginMuteUserEx: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.BeginMuteUserEx();
    },

    // !function EndMuteUserEx
    EndMuteUserEx: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.EndMuteUserEx();
    },

    // !function HoldEx
    HoldEx: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.HoldEx();
    },

    // !function GerHoldEx
    GetHoldEx: function () {
        if (this._isNull()) {
            return null;
        }

        var _return;

        _return = this._ocx.QueryHoldListEx();

        if (_return === 0) {
            if (this._ocx.CallIDNum > 0)
			{
				//get latest callid
				var _CallID = this._ocx.GetCallIDByIdx(this._ocx.CallIDNum - 1);

				return this._ocx.GetHoldEx(_CallID);
			}
			else {
				INFO_LOG_METHOD("AgentOcx", "Interface:GetHoldEx, there is no hold call!");
            return 1;
			}
			
        }
        else {
            INFO_LOG_METHOD("AgentOcx", "Interface:GetHoldEx, error.result:" + _return);
            return 1;
        }
    },

    // !function BeginRecordEx
    BeginRecordEx: function () {
        if (this._isNull()) {
            return null;
        }

        var _Date = new Date();

        var _RecordName = _Date.getYear().toString() + (_Date.getMonth() + 1).toString() + _Date.getDate().toString() + _Date.getUTCMilliseconds().toString() + ".dat";

        //mediatype 5 is voice, now only supports record voice
        return this._ocx.BeginRecordEx(0, _RecordName, 5);
    },

    // !function StopRecordEx
    StopRecordEx: function () {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.StopRecordEx();
    },

    // !function StopRecordEx
    CallOutEx: function (caller, called) {
        if (this._isNull()) {
            return null;
        }

        //CalloutEx(Caller,Called,Mode,Pilot)
        return this._ocx.CallOutEx(caller, called, 0, '');
    },

    // !function CallInnerEx
    CallInnerEx: function (workNo, mediaType) {
        if (this._isNull()) {
            return null;
        }

        //CallInnerEx(Caller,Called,Mode,Pilot)
        return this._ocx.CallInnerEx(workNo, mediaType);
    },

    // !function ConfJoinEx
    ConfJoinEx: function () {
        var _CallID

        if (this._isNull()) {
            return null;
        }

        var _return = this._ocx.QueryHoldListEx();

        if (_return === 0) {
            _CallID = this._ocx.GetCallIDByIdx(0);
        }
        else {
            return 1;
        }

        return this._ocx.ConfJoinEx(_CallID);
    },

    // !function AgentSendDTMF
    AgentSendDTMF: function (dtmf) {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.AgentSendDTMF(dtmf);
    },

    // !function SetCallDataEx
    SetCallDataEx: function (mediaType, calldata) {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.SetCallDataEx(mediaType, calldata);
    },

    // !function DisconnectCall
    DisconnectCall: function () {
        if (this._isNull()) {
            return null;
        }

        var _return = this._ocx.QueryCallIDOnAgentEx(this._ocx.WorkNo);

        if (_return === 0) {
            var _CallID = this._ocx.GetCallIDByIdx(0);

            if (_CallID !== 0) {
                return this._ocx.DisconnectCall(_CallID);
            }
            else {
                INFO_LOG_METHOD("AgentOcx", "Interface:GetCallIDByIdx, error.result:" + _CallID);
                return 1;
            }
        }
        else {
            INFO_LOG_METHOD("AgentOcx", "Interface:QueryCallIDOnAgentEx, error.result:" + _return);
            return _return;
        }
    },
    TransToQueueEx: function (mediaType, transType, usSkillID) {
        if (this._isNull()) {
            return null;
        }

        var _return;
        var _fn;

        _return = this._ocx.TransToQueueEx(mediaType, transType, usSkillID);
        _fn = "TransToQueueEx";
        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:" + _fn + ", error.result:" + _return);
        }
        return _return;

    },
    TransToAgent: function (mediaType, transType, workNo) {
        if (this._isNull()) {
            return null;
        }

        var _return;
        var _fn;

        _return = this._ocx.TransToAgent(mediaType, transType, workNo);
        _fn = "TransToAgent";
        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:" + _fn + ", error.result:" + _return);
        }
        return _return;

    },
    TransToIVR: function (mediaType, transType, accessCode) {
        if (this._isNull()) {
            return null;
        }

        var _return;
        var _fn;

        _return = this._ocx.TransToIVR(mediaType, transType, accessCode);
        _fn = "TransToIVR";
        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:" + _fn + ", error.result:" + _return);
        }
        return _return;

    },
    TransToAccess: function (mediaType, transType, accessCode) {
        if (this._isNull()) {
            return null;
        }

        var _return;
        var _fn;

        _return = this._ocx.TransToAccess(mediaType, transType, accessCode);
        _fn = "TransToAccess";
        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:" + _fn + ", error.result:" + _return);
        }
        return _return;

    },
    TransOutEx2: function (mediaType, transType, number) {
        if (this._isNull()) {
            return null;
        }

        var _return;
        var _fn;

        _return = this._ocx.TransOutEx2(mediaType, '', number, transType, 0, '');
        _fn = "TransOutEx2";
        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:" + _fn + ", error.result:" + _return);
        }
        return _return;

    },
    // !function CallInnerEx
    InternalHelpEx: function (mediaType, workNo, helpMode) {
        if (this._isNull()) {
            return null;
        }

        var _return;
        var _fn;

        _return = this._ocx.InternalHelpEx(mediaType, workNo, helpMode);
        _fn = "InternalHelpEx";

        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:" + _fn + ", error.result:" + _return);
        }
        return _return;
    },
    InternalHelpEx2: function (mediaType, skillID, helpMode) {
        if (this._isNull()) {
            return null;
        }

        var _return;
        var _fn;

        var WorkNo;
        _return = this._ocx.InternalHelpEx2(mediaType, skillID, helpMode, WorkNo);
        _fn = "InternalHelpEx2";

        if (_return !== 0) {
            INFO_LOG_METHOD("AgentOcx", "Interface:" + _fn + ", error.result:" + _return);
        }
        var obj = new Object();
        obj.ret = _return;
        obj.workNo = WorkNo;
        return obj;
    },
    SendChat: function (ccbIdx, content) {
        if (this._isNull()) {
            return null;
        }

        var _return = this._ocx.SendMediaStreamWithCCBIdx(1, ccbIdx, content);
        return _return;
    },

    RequestMultimediaConfEx: function (callID, partNum, agentList) {
        if (this._isNull()) {
            return null;
        }
        var _return = 0;
        _return = this._ocx.RequestMultimediaConfEx(callID, partNum, agentList);
        return _return;
    },
    InviteJoinMultimediaConfEx: function (confID, partNum, agentList) {
        if (this._isNull()) {
            return null;
        }
        var _return = 0;
        _return = this._ocx.InviteJoinMultimediaConfEx(confID, partNum, agentList);
        return _return;
    },
    StopMultimediaConf: function (ulConfID) {
        if (this._isNull()) {
            return null;
        }
        return this._ocx.StopMultimediaConf(ulConfID);
    },

    JoinMultimediaConfResponse: function (ulConfID, usResultCode, usCause) {
        if (this._isNull()) {
            return null;
        }

        return this._ocx.JoinMultimediaConfResponseEx(ulConfID, usResultCode, usCause);
    },
	GetPromptByErrorCode :function(ErrorCode){
		if (this._isNull()) {
            return null;
        }

        return this._ocx.GetPromptByErrorCode(ErrorCode);
	},
	ModifyAgentPwd : function(OldPwd, NewPwd){
		if (this._isNull()) {
            return null;
        }
		
        return this._ocx.ModifyAgentPwd(OldPwd, NewPwd);
	}
}

function GetAgentAutoReleaseSet()
{
	return AgentOcx._ocx.AutoRelease;
}