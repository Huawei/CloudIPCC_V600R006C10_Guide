// Conference Ocx
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var Conference = function()
{
	this._ocx = null;; //ocx object
	
	// !function whether ocx is null(private function)
	this._isNull = function()
	{
		return (null===this._ocx || undefined===this._ocx);
	}
}

Conference.prototype = {
	// !function init Conference
	init: function(ocxId){
		this._ocx = document.getElementById(ocxId);
	},
	// !function Join Conference
	JoinConf: function(sConfInfo)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		//the ConferenceState object is a global obj
		if (typeof(ConferenceState) != "undefined" ){  
			if("function" === typeof(ConferenceState['SetJoiningConf'])){  
				ConferenceState.SetJoiningConf(sConfInfo);
			}
		}
		return this._ocx.JoinConf(sConfInfo);
	},
	// !function Leave Conference
	LeaveConf: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.LeaveConf();
	},
	// !function Terminate Conference
	TerminateConf: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.TerminateConf();
	},
	// !function Limit date flow
	LimitDataFlowSize: function(sDataType, sLimitSize)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.LimitDataFlowSize(sDataType, sLimitSize);
	},
	// !function Get local video devices
	GetLocalVideoDevices: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetLocalVideoDevices();
	},
	// !function Open video device
	OpenVideoDevice: function(sDeviceId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.OpenVideoDevice(sDeviceId);
	},
	// !function Close video device
	CloseVideoDevice: function(sDeviceId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.CloseVideoDevice(sDeviceId);
	},
	// !function Start to draw video
	StartDrawVideo: function(sUserId, sDeviceId, sHWnd, sShowMode)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.StartDrawVideo(sUserId, sDeviceId, sHWnd, sShowMode);
	},
	// !function Stop to draw video
	StopDrawVideo: function(sUserId, sDeviceId, sHWnd)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.StopDrawVideo(sUserId, sDeviceId, sHWnd);
	},
	// !function Pause video
	PauseVideo: function(sUserId, sDeviceId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.PauseVideo(sUserId, sDeviceId);
	},
	// !function Resume video
	ResumeVideo: function(sUserId, sDeviceId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.ResumeVideo(sUserId, sDeviceId);
	},
	// !function Get support video params
	GetSupportVideoParams: function(sDeviceId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetSupportVideoParams(sDeviceId);
	},
	// !function Get current video param
	GetVideoCurrentParam: function(sDeviceId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetVideoCurrentParam(sDeviceId);
	},
	// !function Set current video param
	SetVideoCurrentParam: function(sDeviceId, sVideoParam)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.SetVideoCurrentParam(sDeviceId, sVideoParam);
	},
	// !function Send message
	SendMessage: function(sRecvUserId, sMessage, sMsgId)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.SendMessage(sRecvUserId, sMessage, sMsgId);
	},
	// !function Send file
	SendFile: function(sRecvUserId, sFileAbsolutePath)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.SendFile(sRecvUserId, sFileAbsolutePath);
	},
	// !function Cancel to send file
	CancelSendingFile: function(sFileHandle)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.CancelSendingFile(sFileHandle);
	},
	// !function Receive file
	ReceiveFile: function(sFileHandle, sFileAbsolutePath)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.ReceiveFile(sFileHandle, sFileAbsolutePath);
	},
	// !function Cancel to receive file
	CancelReceiveFile: function(sFileHandle)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.CancelReceiveFile(sFileHandle);
	},
////////////////////////////////////share-screen//////////////////////////////////
	// !function Set display window of share-screen.
	SetDisplayShareScreenWnd: function(sHWnd)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.SetDisplayShareScreenWnd(sHWnd);
	},
	// !function Get application list.
	GetApplicationList: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetApplicationList();
	},
	// !function Add application to share.
	AddApplicationToShare: function(sHAppWnd)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.AddApplicationToShare(sHAppWnd);
	},
	// !function Delete shared-application.
	DeleteSharedApplication: function(sHAppWnd)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.DeleteSharedApplication(sHAppWnd);
	},
	// !function Start screen to share.
	StartShareScreen: function(sShareType)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.StartShareScreen(sShareType);
	},
	// !function Stop screen to share.
	StopShareScreen: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.StopShareScreen();
	},
	// !function request operation privilege.
	RequestOperationPrivilege: function(sPrivilegeType)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.RequestOperationPrivilege(sPrivilegeType);
	},
	// !function set operation privilege to special user.
	SetOperationPrivilege: function(sUserId, sPrivilegeType, sAction)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.SetOperationPrivilege(sUserId, sPrivilegeType, sAction);
	},
	SetShareScreenDisplaySize: function(sWidth, sHeight)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.SetShareScreenDisplaySize(sWidth, sHeight);
	},
	GetPresenter: function()
	{
		if (this._isNull() ) 
		{
			return null;
		}
		return this._ocx.GetPresenter();
	},
	// !function Get description of result code.
	GetResultDesc: function(sResultCode)
	{
		if (this._isNull() ) 
		{
			return null;
		}
		
		return this._ocx.GetResultDesc(sResultCode);
	}
}