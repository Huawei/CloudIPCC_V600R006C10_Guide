// Agent Ocx Event Handle
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var ChatList = Array("","","");



var Event = {};

Event.AgentOcx = {

    OnSignInExSuccess: function (MediaType) {
        AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnSignOutExSuccess: function (MediaType) {
        AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnSayBusySuccess: function () {
    },

    OnSayBusyFailure: function () {
    },

    OnSayFreeSuccess: function () {
    },

    OnSayFreeFailure: function () {
    },

    OnRestExSuccess: function () {

    },

    OnRestExFailure: function () {
    },

    OnCancelRestSuccess: function () {

    },

    OnCancelRestFailure: function () {
    },

    OnStartRest: function () {
        var myDate = new Date();

        alert("Agent start to rest since " + myDate);
		INFO_LOG_METHOD("AgentEvent", "Agent start to rest since " + myDate);
    },

    OnAnswerRequestEx: function (usMediaType) {


        AgentState.SetMediaType(usMediaType);

        AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnAnswerRequestEx2: function (ulTime, usDsn, ucHandle, ucServer, usMediaType, usCCBIdx) {
        AgentState.SetMediaType(usMediaType);
        AgentState.SetCallID(UTIL.FormatCallID(ulTime, usDsn, ucHandle, ucServer));
        AgentState.SetCurrentCallCCBIdx(usCCBIdx);
    },

    OnRequestReleaseEx: function (MediaType) {
        if (!GetAgentAutoReleaseSet()) {
            //document.getElementById("AgentApp.Release").click(); //for convienent purpose , you can uncomment this line to auto fire release action
        }
		AgentState.SetMediaType(MediaType);
        AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnAnswerSuccess: function () {
        AgentState.SetTalkFlag(1);
        AgentUI.UpdateCallStatus();
        //SetBtnStatus("talking");
    },

    OnAnswerExSuccess: function (usMediaType) {
        AgentState.SetTalkFlag(1);

        AgentUI.UpdateCallStatus();

        if (usMediaType === 1) {
            AgentState.SetChatAnswered(AgentState.GetCurrentCallCCBIdx());
        }

    },

    OnReleaseExSuccess: function () {
        var _HoldFlag = AgentState.GetHoldFlag();

        if (_HoldFlag === 0) {
            AgentState.SetTalkFlag(0);
        }

        AgentUI.UpdateCallStatus();
    },

    OnBeginMuteUserSuccess: function () {

    },

    OnEndMuteUserSuccess: function () {

    },

    OnHoldSuccess: function () {
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnGetHoldSuccess: function () {

    },

    OnRecordSuccess: function () {

    },

    OnStopRecordSuccess: function () {

    },

    OnCallOutSuccess: function () {
        AgentState.SetTalkFlag(1);

        AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);

    },

    OnCallInnerSuccess: function () {
        AgentState.SetTalkFlag(1);

        AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnConfJoinSuccess: function () {
        AgentUI.UpdateCallStatus();

    },

    OnConfJoinFailure: function () {

    },

    OnDelCallInConf: function (CallerNo, CalledNo) {
        AgentUI.UpdateCallStatus();
		AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnPhoneStatusNotify: function (Status) {
		AgentUI.UpdateCallStatus();
		AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnInternalHelpSuccess: function (HelpMode) {
        AgentUI.UpdateCallStatus();
    },

    OnInternalHelpRefused: function () {
        AgentUI.UpdateCallStatus();
		AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },

    OnReceiveChat: function (Content) {
		AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
		AgentUI.UpdateCallStatus();
    },

    OnReceiveChatEx: function (sContent, usCCBIdx) {
        AgentState.AgentReiceiveChatContent(usCCBIdx, sContent);
        AgentState.SetTalkFlag(1);
    },

    OnMultimediaConfSuccess: function () {

    },

    OnMultimediaConfFailure: function () {

    },

    OnPrepareJoinMultimediaConf: function (usParticipantType, sParticipant, ulConfID, sConfInfo) {
        AgentState.SetConfID(ulConfID);

        AgentState.SetParticipantType(usParticipantType);
        AgentState.SetParticipant(sParticipant);
        AgentUI.UpdateWhenPrepareJoinMultimediaConf(sConfInfo);


    },

    OnMultimediaConfState: function (usParticipantType, sParticipant, usConfState, usCause) {

    },
    OnStopMultimediaConf: function () {

    },

    OnReceiveAgentStateInfo: function (AgentState, BusyFlag, RestFlag) {
        AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
    },
	OnReceiveReleaseOverEx:function(ulTime, usDsn, ucHandle, ucServer, wMediaType, CCBIdx)
	{
		if (wMediaType === 1) {
			AgentUI.UpdateWhenChatReleased(CCBIdx);
		}
	},
	OnRestTimeOut:function(RestTime){
		alert("Agent rested " + RestTime + "secs, now time out");
		INFO_LOG_METHOD("AgentEvent", "Agent rested " + RestTime + "secs, now time out");
	},
	OnStopMultimediaConf: function()
	{
	
	},
	OnInviteFailure: function()
	{
	
	},
	OnInviteSuccess: function()
	{
	
	},
	OnStopMultimediaConfFailure: function()
	{
	
	},
	OnAnswerExFailure:function(MediaType)
	{
	
	},
	OnHoldCallRelease:function(Cause)
	{
	
	},
	OnGetHoldSuccTalk:function()
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnCallInnerSuccTalk:function()
	{
	},
	OnCallerCalledInfoArrived: function(MediaType,Caller,Called)
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnInternalHelpFailure: function(HelpMode)
	{
	},
	OnSayBusySuccess:function()
	{
	
	},
	OnSayBusyFailure:function()
	{
	},
	OnSayFreeSuccess:function()
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnSayFreeFailure:function()
	{
	},
	OnIsTalkingChanged:function()
	{
	},
	OnBeforeTrans:function()
	{
	},
	OnRedirectToOtherSuccess:function()
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnRedirectToOtherFailure:function()
	{
	},
	OnTransInnerFailure:function()
	{
	},
	OnTransInnerSuccess:function()
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnRedirectToAutoSuccess:function()
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnRedirectToAutoFailure:function()
	{
	},
	OnReturnFromIvr:function()
	{
	},
	OnTransOutSuccess:function(TransMode)
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnTransOutFailure:function(TransMode)
	{
	},
	OnTransOutFailTalk:function(TransMode)
	{
	},
	OnForceOutEx: function(usSuccess)
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	},
	OnReceiveForceoutMsgEx: function(usSuccess, usMediaType)
	{
		AgentUI.UpdateCallStatus();
        AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
	}
	
}