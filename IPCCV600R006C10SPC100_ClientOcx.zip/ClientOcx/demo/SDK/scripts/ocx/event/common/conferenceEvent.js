// Conference Ocx Event Handle
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

Event.ConferenceOcx = {
	ConfInitResultEvent: function(sEventInfo)
	{
	},
	
	JoinConfResultEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
		var resultCode = obj.resultCode;
		var resultDesc = obj.resultDesc;		

		//if it is the userapp that fires the JoinConfResultEvent, automatically fire the ReportJoinMeetingResult click event
        if (resultCode === 0)
		{
            ConferenceState.SetJoiningConfResultSuccess(resultCode);
        }
        else
        {
            ConferenceState.SetJoiningConfResultFailed(resultCode);
        }
        return '';
	},
	
	TerminateConfResultEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
        if (obj.resultCode === 0){
            ConferenceState.SetTeminateConfResultSuccess();
        }
        else {   
            ConferenceState.SetTeminateConfReulstFailed();
        }
		return '';
	},
	
	MemberEnterConfEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);

		ConferenceState.SetMemberEntered(obj.userId, obj.userFlag, obj.userRole);
	},
	
	MemberLeaveConfEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);		
		ConferenceState.SetMemberLeaved(obj.userId, obj.isSelf);
	},
	VideoSwitchEvent: function(sEventInfo)
	{
        var obj = JSON.parse(sEventInfo);
        if (obj.status === 1)// there is a video device opened
        {
           ConferenceState.SetVideoDeviceOpened(obj.userId, obj.deviceId);
        } 
        else if ( obj.status === 0 ) // there is a video device closed
        {
            ConferenceState.SetVideoDeviceClosed(obj.userId, obj.deviceId);
        }

	},
	MessageArrivedEvent: function(sEventInfo)
	{
	},
	FileTranProgressEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
		if (obj.fileStatus === "1") // receiveFile progress
		{
			ConferenceState.SetFileTransRecvProgress(obj.fileHandle, obj.fileName, obj.fileSize, obj.fileProgress, obj.senderId, obj.resultCode);
		}
		else if (obj.fileStatus === "3")//send file progress
		{
		    ConferenceState.SetFileTransSendProgress(obj.fileHandle, obj.fileName, obj.fileSize, obj.fileProgress, obj.senderId, obj.resultCode); ; //file transfered progress 
		}
	},
	FileTranOverEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
		if (obj.fileStatus === "1") // receiveFile progress
		{
			if (obj.resultCode === 0)
			{
				ConferenceState.SetFileTransRecvOverSuccess(obj.fileHandle, obj.fileName, obj.fileSize, obj.senderId);
			}
			else
			{
				ConferenceState.SetFileTransRecvOverFailed(obj.fileHandle, obj.fileName, obj.fileSize, obj.senderId, obj.resultCode);
			}
		}
		else if (obj.fileStatus === "3")//send file progress
		{
			if (obj.resultCode === 0)
			{
				ConferenceState.SetFileTransSendOverSuccess(obj.fileHandle, obj.fileName, obj.fileSize, obj.senderId);
			}
			else
			{
				ConferenceState.SetFileTransSendOverFailed(obj.fileHandle, obj.fileName, obj.fileSize, obj.senderId, obj.resultCode);
			}
		}
	},
	FileArrivedEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
        ConferenceState.SetFileArrived(obj.fileHandle, obj.fileName, obj.fileSize, obj.fileStatus, obj.senderId);
	},
	StartShareScreenResultEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
		ConferenceState.SetStartShareScreenResult(obj.resultCode);
	},
	SharingOwnerNotifyEvent: function(sEventInfo)
	{
	},
	ShareScreenStateNotifyEvent: function(sEventInfo)
	{
	},
	OperationPrivilegeRequestEvent: function(sEventInfo)
	{
	},
	OperationPrivilegeStateEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
		ConferenceState.SetOperationPrivilegeState(obj.action, obj.privilegeType, obj.userId);
	},
	ShareScreenWndSizeEvent: function(sEventInfo)
	{
		var obj = JSON.parse(sEventInfo);
		var displaySet = new Object();
		displaySet.x = obj.X;
		displaySet.y = obj.Y;
		ConferenceState.SetDesktopShareDisplaySet(displaySet);
	},
	LoadComponentFailedEvent: function(sEventInfo)
	{
	},
	ConfNetWorkDisconnectedEvent: function()
	{
	},
	ConfNetWorkStatusEvent: function(sEventInfo)
	{
	},
	ConfRemainingTimeEvent: function(sEventInfo)
	{
	},
	ConfVideoDisconnectedEvent: function()
	{
	},
	ConfVideoNotifyEvent: function(sEventInfo)
	{
	},
	ConfVideoFlowWarningEvent: function(sEventInfo)
	{
	}
}
