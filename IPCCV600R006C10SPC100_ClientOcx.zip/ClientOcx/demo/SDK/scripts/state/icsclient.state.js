//icsclient user state
ICSCLIENT_USER_STATE = {
    ICS_USER_STATE_NO_LOGIN:0,
    ICS_USER_STATE_LOGIN:1
}
//icsclient call state
ICSCLIENT_CALL_STATUS = {   
    ICSCLIENT_CALL_STATUS_DISCONNECTED:0,
	ICSCLIENT_CALL_STATUS_ALERTING:1,
    ICSCLIENT_CALL_STATUS_QUEUEING:2,
    ICSCLIENT_CALL_STATUS_CONNECTED:3
}
//icsclient call type 
ICSCLIENT_USER_CALLTYPE = {  
    ICSCLIENT_USER_CALLTYPE_WEBCHAT:1,
    ICSCLIENT_USER_CALLTYPE_CLICKCALL:2,
    ICSCLIENT_USER_CALLTYPE_CALLBACK:4,
	ICSCLIENT_USER_CALLTYPE_VCCALL:22
}

//icsclientstateclass constructor
function ICSClientStateClass() {
    this._userState = ICSCLIENT_USER_STATE.ICS_USER_STATE_NO_LOGIN;
    this._currentCallUVID = -1;
    this._currentCallID = "";
    this._anonymousCallee = "";
    this._webChatCallState = { callID: "", uvid:-1, status: ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED }; // callstate is an object 
    this._clickCallState = { callID: "", uvid: -1, status: ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED }; // callstate is an object 
    this._callbackState = { callID: "", uvid: -1, status: ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED }; // callstate is an object
	this._vcCallState = { callID: "", uvid: -1, status: ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED }; // callstate is an object
    this._chatContent = "";
    this.SetUserAppState = function (state) {
        this._userState = state;
    }
    this.GetUserAppState = function () {
        return this._userState;
    }

    this.SetCurrentCallUVID = function (uvid) {
        this._currentCallUVID = uvid;
    }

    this.GetCurrentCallUVID = function () {
        return this._currentCallUVID;
    }

    this.SetCurrentCallID = function (callID) {
        this._currentCallID = callID;
    }

    this.GetCurrentCallID = function () {
        return this._currentCallID;
    }

    this.SetWebChatCallState = function (callID, status, uvid) {
        this._webChatCallState.callID = callID;
        this._webChatCallState.status = status;
        this._webChatCallState.uvid = uvid;
    }

    this.GetWebChatCallState = function () {
        return this._webChatCallState;
    }
    this.SetClickCallCallState = function (callID, status, uvid) {
        this._clickCallState.callID = callID;
        this._clickCallState.status = status;
        this._clickCallState.uvid = uvid;
    }

    this.GetClickCallCallState = function () {
        return this._clickCallState;
    }
    this.SetCallBackCallState = function (callID, status, uvid) {
        this._callbackState.callID = callID;
        this._callbackState.status = status;
        this._callbackState.uvid = uvid;
    }

    this.GetCallBackCallState = function () {
        return this._callbackState;
    }
	this.SetVCCallState = function (callID, status, uvid) {
        this._vcCallState.callID = callID;
        this._vcCallState.status = status;
        this._vcCallState.uvid = uvid;
    }

    this.GetVCCallState = function () {
        return this._vcCallState;
    }

    this.HasTalkOfCallType = function (calltype) {
        if (calltype === ICSCLIENT_USER_CALLTYPE.ICSCLIENT_USER_CALLTYPE_WEBCHAT) {
            if (this.GetWebChatCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED){
                return false;
            }
            else {
                return true;
            }
        }
        else if (calltype === ICSCLIENT_USER_CALLTYPE.ICSCLIENT_USER_CALLTYPE_CLICKCALL) {
            if (this.GetClickCallCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED) {
                return false;
            }
            else {
                return true;
            }
        }
        else if (calltype === ICSCLIENT_USER_CALLTYPE.ICSCLIENT_USER_CALLTYPE_CALLBACK) {
            if (this.GetCallBackCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED) {
                return false;
            }
            else {
                return true;
            }
        }
		else if (calltype === ICSCLIENT_USER_CALLTYPE.ICSCLIENT_USER_CALLTYPE_VCCALL) {
            if (this.GetVCCallState().status === ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            ERROR_LOG_METHOD("ICSClientState", "wrong state here, maybe you have bug here?");
            return false;
        }
    }
    this.SetAnonymousCallee = function(callee){   
        this._anonymousCallee = callee;
    }

    this.GetAnonymousCallee = function(){  
        return this._anonymousCallee;
    }

    this.AppendChatContent = function (content) {
        this._chatContent += content + "\r\n";
    }

    this.ReceiveChatContent = function (sender, content) {
        this.AppendChatContent(sender + ":" + content);
        ICSClientUI.UpdateWhenChatContentReceived();
    }

    this.SendChatContent = function (sender, content) {
        this.AppendChatContent(sender + ":" + content);
        ICSClientUI.UpdateWhenChatContentSent();
    }
    this.ClearChatContent = function () {
        this._chatContent = "";
        ICSClientUI.UpdateWhenChatContentCleared();
    }
    
    this.GetChatContent = function () {
        return this._chatContent;
    }
}


ICSClientStateClass.prototype = {
	AlertWebChat:function(callID){
		this.SetWebChatCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenWebChatCallBegin();
	},
	EndAlertWebChat:function(){
		this.SetWebChatCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID("");
        ICSClientUI.UpdateWhenWebChatCallEnd();
	},
	AlertClickCall:function(callID){
		this.SetClickCallCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenClickCallCallBegin();
	},
	EndAlertClickCall:function(){
		this.SetClickCallCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID("");
        ICSClientUI.UpdateWhenClickCallCallEnd();
	},
	AlertCallBack:function(calllID){
		this.SetCallBackCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenCallBackCallBegin();
	},
	EndAlertCallBack:function(){
		this.SetCallBackCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID("");
        ICSClientUI.UpdateWhenCallBackCallEnd();
	},
	AlertVCCall:function(callID){
		this.SetVCCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenVCCallBegin();
	},
	EndAlertVCCall:function(){
		this.SetVCCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_ALERTING, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID("");
        ICSClientUI.UpdateWhenVCCallEnd();
	},
    BeginWebChat: function (callID, uvid) {
        this.SetWebChatCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED, uvid);
        this.SetCurrentCallUVID(uvid);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenWebChatCallBegin();
    },
    EndWebChat: function () {
        this.SetWebChatCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        ICSClientUI.UpdateWhenWebChatCallEnd();
    },
    BeginClickCall: function (callID, uvid, anonymousCallee) {
        this.SetAnonymousCallee(anonymousCallee);
        this.SetClickCallCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED, uvid);
        this.SetCurrentCallUVID(uvid);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenClickCallCallBegin();
    },
    EndClickCall: function () {
        this.SetClickCallCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetAnonymousCallee("");
        ICSClientUI.UpdateWhenClickCallCallEnd();
    },
    BeginCallBack: function (callID, uvid) {
        this.SetCallBackCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED, uvid);
        this.SetCurrentCallUVID(uvid);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenCallBackCallBegin();
    },
    EndCallBack: function () {
        this.SetCallBackCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        ICSClientUI.UpdateWhenCallBackCallEnd();
    },
	BeginVCCall: function (callID, uvid) {
        this.SetVCCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_CONNECTED, uvid);
        this.SetCurrentCallUVID(uvid);
        this.SetCurrentCallID(callID);
        ICSClientUI.UpdateWhenVCCallBegin();
    },
    EndVCCall: function () {
        this.SetVCCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        ICSClientUI.UpdateWhenVCCallEnd();
    },
    SetLoginSuccess: function () {
        //when first login , the state should be initialized
        this.SetClickCallCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetClickCallCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetCallBackCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID("");
        this.SetAnonymousCallee("");
        this.SetUserAppState(ICSCLIENT_USER_STATE.ICS_USER_STATE_LOGIN);
        ICSClientUI.UpdateWhenUserLogin();
    },
    SetLogoutSuccess: function () {
        this.SetClickCallCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetClickCallCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetCallBackCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        this.SetCurrentCallUVID(-1);
        this.SetCurrentCallID("");
        this.SetAnonymousCallee("");
        this.SetUserAppState(ICSCLIENT_USER_STATE.ICS_USER_STATE_NO_LOGIN);
        ICSClientUI.UpdateWhenUserLogout();
    },

    BeginWebChatQueueing: function (callID, uvid) {
        this.SetWebChatCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING, uvid);
        this.SetCurrentCallID(callID);
        this.SetCurrentCallUVID(uvid);
        ICSClientUI.UpdateWhenUserQueueing();
    },
    EndWebChatQueueing: function (callID, uvid) {
        this.SetWebChatCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        ICSClientUI.UpdateWhenUserQueueingEnd();
    },
    BeginClickCallQueueing: function (callID, uvid) {
        this.SetClickCallCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING, uvid);
        this.SetCurrentCallID(callID);
        this.SetCurrentCallUVID(uvid);
        ICSClientUI.UpdateWhenUserQueueing();
    },
    EndClickCallQueueing: function (callID, uvid) {
        this.SetClickCallCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        ICSClientUI.UpdateWhenUserQueueingEnd();
    },
    BeginCallBackQueueing: function (callID, uvid) {
        this.SetCallBackCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING, uvid);
        this.SetCurrentCallID(callID);
        this.SetCurrentCallUVID(uvid);
        ICSClientUI.UpdateWhenUserQueueing();
    },
    EndCallBackQueueing: function (callID, uvid) {
        this.SetCallBackCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        ICSClientUI.UpdateWhenUserQueueingEnd();
    },
	BeginVCCallQueueing: function (callID, uvid) {
        this.SetVCCallState(callID, ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_QUEUEING, uvid);
        this.SetCurrentCallID(callID);
        this.SetCurrentCallUVID(uvid);
        ICSClientUI.UpdateWhenUserQueueing();
    },
    EndVCCallQueueing: function (callID, uvid) {
        this.SetVCCallState("", ICSCLIENT_CALL_STATUS.ICSCLIENT_CALL_STATUS_DISCONNECTED, -1);
        ICSClientUI.UpdateWhenUserQueueingEnd();
    }
}
