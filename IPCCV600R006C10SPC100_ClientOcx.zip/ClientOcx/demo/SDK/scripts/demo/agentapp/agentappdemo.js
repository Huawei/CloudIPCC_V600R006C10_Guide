﻿// AgentApp demo
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

var AgentAppDemo = function () {
    this.CreateVideoDeviceWindow = function (userId, deviceId) {
        //create window
        var hwndInfo = WndUiExcute('Create', 'Video_' + userId + '_' + deviceId);
        var obj = JSON.parse(hwndInfo);
        //start draw the video
        ConferenceExcute('StartDrawVideo', userId, deviceId, obj.hWnd, 1); //mode 1 indicates that it draws the video by ratio
        WndUiUI.UpdateWindowList();
        return '';
    }
    this.CloseVideoDeviceWindow = function (userId, deviceId, hWnd) {
        //stop draw the video
        ConferenceExcute('StopDrawVideo', userId, deviceId, hWnd);
        //destroy the window
        WndUiExcute("Destroy", hWnd);
        WndUiUI.UpdateWindowList();
        return "";
    }
    this.CreateDesktopShareWindow =  function () {
        // create windows
        var hwndInfo = WndUiExcute("Create", 'DesktopShare Window');
        var obj = JSON.parse(hwndInfo);
        ConferenceState.SetDesktopShareHwnd(obj.hWnd);
        //set desktop share display window
        ConferenceExcute('SetDisplayShareScreenWnd', ConferenceState.GetDesktopShareHwnd());
        WndUiUI.UpdateWindowList();
        return '';
    }

    this.OpenDialog = function (dialogName, arguments, width, height) {
        var arg = arguments;
        arg.dialog = dialogName;
		arg.Config = Config;
        dialogRet = window.showModalDialog("scripts/demo/common/dialog.html", arg, "dialogWidth=" + width + "px;dialogHeight=" + height + "px;status=yes;scroll=no;help=no;");
        return dialogRet;
    }

    this.ChooseConfMemberUser = function (tipmessage) {
        var arg = new Object();
		if (arg === null || arg === undefined){
			INFO_LOG_METHOD("UserAppDemo","someting go wrong here, the arg is null");
			return;
		}
        arg.memberList = ConferenceState.GetConfMemberList();
        arg.tipmessage = tipmessage;
        var userid = AgentAppDemoExcute("OpenDialog", "ChooseConfMember", arg, 400, 300);
        //if not correct selected, return null
        if (typeof userid === "undefined") {
            return null;
        }
        return userid;
    }

    this.ChooseVideoParam = function () {
        var arg = new Object();
        var paramInfo = ConferenceExcute("GetSupportVideoParams", UserState.GetSelectedVideoDevice());
        var obj = JSON.parse(paramInfo);
        if (obj.resultCode != 0) {
            INFO_LOG_METHOD("AgentAppDemo","Get Support Video Param Failed");
            return;
        }
        var paramList = [];
        for (var i = 0; i < obj.supportVideoParam.length; i++) {
            paramList.push(JSON.stringify(obj.supportVideoParam[i]));
        }
        arg.paramList = paramList;
        arg.tipmessage = "Set video param";
        var param = AgentAppDemoExcute("OpenDialog", "ChooseVideoParam", arg, 600, 400);
        //if not correct selected, return null
        if (typeof param === "undefined") {
            return null;
        }
        return param;
    }
    this.ChooseLocalVideoDevice = function () {
        var arg = new Object();
        arg.deviceList = ConferenceState.GetLocalDeviceList();
        arg.tipmessage = "I18N_DIALOG_TIPMESSAGE_CHOOSE_LOCAL_VIDEO";
        var deviceid = AgentAppDemoExcute("OpenDialog", "ChooseLocalVideoDevice", arg, 600, 300);
        //if not correct selected, return null
        if (typeof deviceid === "undefined") {
            return null;
        }
        return deviceid;
    }
	this.QueryErrorCode = function (ocx, errCode) {
        if (ocx === 'ConferenceOcx') {
            return ConferenceExcute("GetResultDesc", errCode);
        }
        else if (ocx === 'VoiceOcx') {
            return VoiceExcute("GetResultDesc", errCode);
        }
        else if (ocx === 'ICSClientOcx') {
            return ICSClientExcute("GetResultDesc", errCode);
        }
		else if (ocx === 'AgentOcx'){
			return AgentExcute("GetPromptByErrorCode", errCode);
		}
    }
	
}

//define methods for the ui action
AgentAppDemo.prototype =
{
    Login: function (WorkNo, AgentPwd, ProgID, PhoneNumber) {
        var error =  AgentExcute('SignInEx', WorkNo, AgentPwd, ProgID, PhoneNumber);
		if (error === 548)//548 indicates that agent need to modify password
		{
			var pwdInfo = OpenModifyPWDDialog();			
			return AgentExcute('ModifyAgentPwd',pwdInfo.OldPWD, pwdInfo.NewPWD,pwdInfo.ConfirmPWD);
		}
    },
    Logout: function () {
        return AgentExcute('SignOutEx');
    },
	ModifyPWD: function(){
		var pwdInfo = OpenModifyPWDDialog();		
		return AgentExcute('ModifyAgentPwd',pwdInfo.OldPWD, pwdInfo.NewPWD,pwdInfo.ConfirmPWD);
	},
    Register: function (PhoneNumber, PhonePwd) {
        return AgentExcute('Register', PhoneNumber, PhonePwd);
    },
    Deregister: function () {
        return VoiceExcute("Deregister");
    },
    AnswerPhone: function () {
        return VoiceExcute("Answer", VoicePhoneState.GetCurrentCallID());
    },
    ReleasePhone: function () {
        return VoiceExcute("Release", VoicePhoneState.GetCurrentCallID());
    },
    SayBusy: function () {
        return AgentExcute('SayBusy');
    },
    SayFree: function () {
        return AgentExcute('SayFree');
    },
    AgentEnterWork: function () {
        return AgentExcute('AgentEnterWork');
    },
    AgentEnterIdle: function () {
        return AgentExcute('AgentEnterIdle');
    },
    BusyWithReason: function () {
        var busyInfo = OpenBusyDialog();
        if (typeof busyInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try rest, but dialog operation not correct.");
            return '';
        }
        if (busyInfo.RestCause === "") {
            WARN_LOG_METHOD("AgentAppDemo", "No Busy reason setted, please set vdn reason first");
            return '';
        }
        return AgentExcute("SayBusyWithReason", busyInfo.RestCause);
    },
    AnswerAgentTalk: function () {
        return AgentExcute("AnswerEx", AgentState.GetMediaType());
    },
    ReleaseAgentTalk: function () {
		//if it is webchat ,info the user to release in webchat tab
		if (AgentState.GetMediaType() === 1){
			WARN_LOG_METHOD("AgentAppDemo", "Please release webchat in the webchat tabpage!");
		}
		else {
			 AgentExcute("ReleaseCallEx", AgentState.GetMediaType(), AgentState.GetCurrentCallCCBIdx());
		}
		AgentUI.UpdateCallStatus();
		AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
		return '';
    },
    BeginMute: function () {
        return AgentExcute('BeginMuteUserEx');
    },
    EndMute: function () {
        return AgentExcute('EndMuteUserEx');
    },
    HoldCall: function () {
        AgentExcute('HoldEx');
		AgentUI.UpdateCallStatus();
		AgentUI.UpdateAgentStatus(AgentOcx._ocx.WorkNo);
		return '';
    },
    GetHold: function () {
        AgentExcute('GetHoldEx');
		AgentUI.UpdateCallStatus();
		return '';
    },
    BeginRecordEx: function () {
        return AgentExcute('BeginRecordEx');
    },
    StopRecordEx: function () {
        return AgentExcute('StopRecordEx');
    },
    CallOut: function () {
        var callOutInfo = OpenCallOutDialog();
        if (typeof callOutInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try CallOut, but dialog operation not correct.");
            return '';
        }
        if (callOutInfo.Called === "") {
            ERROR_LOG_METHOD("AgentAppDemo", "callout number not filled.");
            return '';
        }
        return AgentExcute("CallOutEx", callOutInfo.Caller, callOutInfo.Called);
    },
    InnerCall: function () {
        var retInfo = OpenInnerCallDialog();
        if (typeof retInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try CallOut, but dialog operation not correct.");
            return '';
        }
        if (retInfo === "") {
            ERROR_LOG_METHOD("AgentAppDemo", "agentid not filled.");
            return '';
        }
        return AgentExcute("CallInnerEx", retInfo, 5);
    },
    ConfJoinEx: function () {
        return AgentExcute('ConfJoinEx');
    },
    DTMF: function () {
        var retInfo = OpenDTMFDialog();
        if (typeof retInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try dtmf, but dialog operation not correct.");
            return '';
        }
        if (retInfo === "") {
            ERROR_LOG_METHOD("AgentAppDemo", "dtmf not filled.");
            return '';
        }
        return AgentExcute("AgentSendDTMF", retInfo);
    },
    CallData: function () {
        var retInfo = OpenCallDataDialog();
        if (typeof retInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try set calldata, but dialog operation not correct.");
            return '';
        }
        return AgentExcute("SetCallDataEx", 5, retInfo);
    },
    SendChat: function (content) {
        var ret =  AgentExcute("SendChat", AgentState.GetChatCCBIdx(), content);
		if (ret !== 0){ 
			content = "<!failed>" + content;
		}
		AgentState.AgentSendChatContent(AgentState.GetChatCCBIdx(), AgentState.GetWorkNo() + ":"+ decodeURI(content));
        return ret;
    },
    InnerHelp: function () {
        var retInfo = OpenInnerHelpDialog();
        if (typeof retInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try InnerHelp, but dialog operation not correct.");
            return '';
        }
        if (retInfo.HelpDevice === "1") { // to skill
			if ( !UTIL.CheckIsNumber(retInfo.HelpSkillNo)){
				ERROR_LOG_METHOD("AgentAppDemo", "Help SkillNo number input not correct!");
				return '';
			}
            return AgentExcute("InternalHelpEx2", 5, retInfo.HelpSkillNo, retInfo.HelpType);
        }
        else {  // to agent
			if ( !UTIL.CheckIsNumber(retInfo.HelpWorkNo)){
				ERROR_LOG_METHOD("AgentAppDemo", "Help WorkNo number input not correct!");
				return '';
			}
            if (retInfo.HelpWorkNo <= 0) {
                ERROR_LOG_METHOD("AgentAppDemo", "try InnerHelp, workno less than 0.");
            }
            return AgentExcute("InternalHelpEx", 5, retInfo.HelpWorkNo, retInfo.HelpType);
        }
        ERROR_LOG_METHOD("AgentAppDemo", "innerhelp helptype incorrect!");
        return "";
    },
    Transfer: function () {
        var retInfo = OpenTransferDialog();
        if (typeof retInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try Transfer, but dialog operation not correct.");
            return '';
        }
        if (retInfo.DeviceType === "1") {
			if ( !UTIL.CheckIsNumber(retInfo.DeviceNo)){
				ERROR_LOG_METHOD("AgentAppDemo", "Target queue not correct!");
				return '';
			}
            return AgentExcute("TransToQueueEx", 5, retInfo.TransType, retInfo.DeviceNo);
        }
        else if (retInfo.DeviceType === "2") {
			if ( !UTIL.CheckIsNumber(retInfo.DeviceNo)){
				ERROR_LOG_METHOD("AgentAppDemo", "Target agent not correct!");
				return '';
			}
            return AgentExcute("TransToAgent", AgentState.GetMediaType(), retInfo.TransType, retInfo.DeviceNo);
        }
        else if (retInfo.DeviceType === "3") {
			if ( !UTIL.CheckIsNumber(retInfo.DeviceNo)){
				ERROR_LOG_METHOD("AgentAppDemo", "Target ivr not correct!");
				return '';
			}
            return AgentExcute("TransToIVR", 5, retInfo.TransType, retInfo.DeviceNo);
        }
        else if (retInfo.DeviceType === "4") {
			if ( !UTIL.CheckIsNumber(retInfo.DeviceNo)){
				ERROR_LOG_METHOD("AgentAppDemo", "Target accesscode not correct!");
				return '';
			}
            return AgentExcute("TransToAccess", 5, retInfo.TransType, retInfo.DeviceNo);
        }
        else if (retInfo.DeviceType === "5") {
            return AgentExcute("TransOutEx2", 5, retInfo.TransType, retInfo.DeviceNo);
        }
        ERROR_LOG_METHOD("AgentAppDemo", "transfer DeviceType incorrect!");
        return "";
    },
    MultiConf: function () {
        var retInfo = OpenMultiConfDialog();
        if (typeof retInfo === "undefined") {
            ERROR_LOG_METHOD("AgentAppDemo", "try multiconf, but dialog operation not correct.");
            return '';
        }
        if (retInfo.OprType === "1") {
			if ( !UTIL.CheckIsNumber(retInfo.PartNum)){
				ERROR_LOG_METHOD("AgentAppDemo", "agent number input not correct!");
				return '';
			}
            return AgentExcute("RequestMultimediaConfEx", AgentState.GetCallID(), retInfo.PartNum, retInfo.AgentList);
        }
        else if (retInfo.OprType === "2") {
			if ( !UTIL.CheckIsNumber(retInfo.PartNum)){
				ERROR_LOG_METHOD("AgentAppDemo", "agent number input not correct!");
				return '';
			}
			
            if (ConferenceState.GetCurrentJoinedConfID() === "") {
                ERROR_LOG_METHOD("AgentAppDemo", "InviteJoinMultimediaConfEx failed, there is no meeting!");
                return "";
            }
			
            return AgentExcute("InviteJoinMultimediaConfEx", ConferenceState.GetCurrentJoinedConfID(), retInfo.PartNum, retInfo.AgentList);
        }
        ERROR_LOG_METHOD("AgentAppDemo", "MultiConf oprtype in correct incorrect!");
        return '';
    },
    LeaveConf: function () {
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: There is no meeting to leave.';
        }
        return ConferenceExcute("LeaveConf");
    },
    TerminateConf: function () {
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: There is no meeting.';
        }
		var presenterId = ConferenceState.GetPresenter();
		if (presenterId === null)
		{
			INFO_LOG_METHOD("AgentAppDemo", "Failed to get presenterId,Try to terminate meeting now");
			return ConferenceExcute("TerminateConf");
		}
		if (ConferenceState.IsSelfUser(presenterId))
		{
			INFO_LOG_METHOD("AgentAppDemo", "Presenter teminate meeting");
			return ConferenceExcute("TerminateConf");
		}
		else
		{
			INFO_LOG_METHOD("AgentAppDemo", "party leave meeting");
			return ConferenceExcute("LeaveConf");
		}
    },
    //multimedia methods define below
    ShowWindow: function (hwnd, width, height) {
		if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
		if (!UTIL.CheckIsNumber(width) || !UTIL.CheckIsNumber(height)){
			return 'ERROR: width or height input error';
		}
		if (width <= 0 || height <= 0){
			return 'ERROR: width or height <= 0';
		}
		var wndList = WndUiState.GetWndList();
		var title = "";
        for (var i = 0; i < wndList.length; i++) {
            if (wndList[i].hwnd === parseInt(hwnd)) {
				title = wndList[i].title;
                break;
            }
        }
		//if try to show a desktopshare window
		if (title.indexOf("DesktopShare") >= 0){
			
			var changedHeight = width*(ConferenceState.GetDesktopShareDisplaySet().y/ConferenceState.GetDesktopShareDisplaySet().x);
			ConferenceExcute("SetShareScreenDisplaySize", parseInt(width), parseInt(changedHeight));
			return WndUiExcute('Show', hwnd, parseInt(width)+15, parseInt(changedHeight) + 35);//add 2 for the border width of the window,add 27 for the border height of the window
		}
		else{
			return WndUiExcute('Show', hwnd, parseInt(width), parseInt(height));
		}
	},
	SetVideoParam: function () {
		if (ConferenceState.GetCurrentJoinedConfID() === "") {
			return 'ERROR: please create meeting first';
		}
		var param = AgentAppDemoExcute("ChooseVideoParam");
		if (param === null) {
			return 'ERROR: operation not correctly, device not selected ';
		}
		if (param === undefined) {
			return 'ERROR: operation not correctly, device not selected ';
		}
		// first close it
		ConferenceExcute("CloseVideoDevice", UserState.GetSelectedVideoDevice());
		var setParamExcute = "ConferenceExcute('SetVideoCurrentParam'," + UserState.GetSelectedVideoDevice() + ",\'" + param + "\')";
		var t1 = setTimeout(setParamExcute, 1500)
		//ConferenceExcute('SetVideoCurrentParam', UserState.GetSelectedVideoDevice(), param);
		var t2 = setTimeout(" ConferenceExcute('OpenVideoDevice'," + " " + UserState.GetSelectedVideoDevice() + ")", 2000);
		//ConferenceExcute("OpenVideoDevice", UserState.GetSelectedVideoDevice());
	},
    SendFile: function (sendfile) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        var userid = AgentAppDemoExcute("ChooseConfMemberUser", "I18N_DIALOG_TIPMESSAGE_SENDFILE");
        if (userid === null) {
            return 'ERROR: operation not correctly, conf member not chosen';
        }
        if (ConferenceState.IsSelfUser(userid)) {
            return 'ERROR: can not send file to yourself';
        }
        if (!ConferenceState.IsInConfMemberList(userid)) {
            return 'ERROR: userid:' + userid + " not in the meeting now";
        }

        return ConferenceExcute('SendFile', userid, sendfile);
    },
    CancelSendFile: function (filehandle) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        return ConferenceExcute('CancelSendingFile', filehandle);
    },
    ReceiveFile: function (fileHandle, savefile) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        return ConferenceExcute('ReceiveFile', fileHandle, savefile);
    },
    CancelReceive: function (fileHandle) {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        return ConferenceExcute('CancelReceiveFile', fileHandle);
    },
    OpenLocalVideo: function () {
		//check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        if (UserState.GetIsLocalVideoOpened()) {
            return ConferenceExcute('CloseVideoDevice', UserState.GetSelectedVideoDevice());
        }
        var deviceid = AgentAppDemoExcute("ChooseLocalVideoDevice");
        if (deviceid === null) {
            return 'ERROR: operation not correctly, device not selected ';
        }
        if (deviceid <= 0) {
            return 'ERROR: operation not correctly, device not selected ';
        }
        UserState.SetSelectedVideoDevice(deviceid);
        return ConferenceExcute('OpenVideoDevice', deviceid);
    },
    CloseLocalVideo: function () {
		//check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        if (UserState.GetIsLocalVideoOpened())
        {
            return ConferenceExcute('CloseVideoDevice', UserState.GetSelectedVideoDevice());
        }
		else
		{
			INFO_LOT_METHOD("UserAppDemo","Video deivice not opened");
		}
        return ConferenceExcute('CloseVideoDevice', deviceid);
    },
    StartDesktopShare: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        //share desktop share
        return ConferenceExcute('StartShareScreen', 'desktop');

    },
    StopDesktopShare: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        //stop desktop share
        return ConferenceExcute('StopShareScreen');
    },
    AllowRemoteCtrl: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }

        var userid = AgentAppDemoExcute("ChooseConfMemberUser", "I18N_DIALOG_TIPMESSAGE_ALLOW_REMOTE_CTRL");
        if (userid === null) {
            return 'ERROR: operation not correctly, conf member not chosen';
        }
        if (ConferenceState.IsSelfUser(userid)) {
            return 'ERROR: can not set yourself the remotectrl privileage';
        }
        if (!ConferenceState.IsInConfMemberList(userid)) {
            return 'ERROR: userid:' + userid + " not in the meeting now";
        }

        return ConferenceExcute('SetOperationPrivilege', userid, 'remotectl', 'add');
    },
    StopRemoteCtrl: function () {
        //check if there is a meeting
        if (ConferenceState.GetCurrentJoinedConfID() === "") {
            return 'ERROR: please create meeting first';
        }
        return ConferenceExcute('SetOperationPrivilege', ConferenceState.GetDesktopShareControlUser(), 'remotectl', 'delete'); //stop the currentTalking user to control
    }
}


