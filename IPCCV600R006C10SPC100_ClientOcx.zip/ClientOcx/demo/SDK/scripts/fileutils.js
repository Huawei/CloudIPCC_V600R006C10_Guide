// Date extension
// Copyright © Huawei Technologies Co., Ltd. 2012. All rights reserved.

Date.SIMPLE_FORMAT = "yyyy-MM-dd hh:mm:ss";			//simple format
Date.DATETIME_FORMAT = "yyyy-MM-dd hh:mm:ss:SSS";	//time format
Date.DAY_FORMAT = "yyyyMMdd";						//day format

// !function
// desc: date format
// params:
// [IN] format : date format
// return : date string
Date.prototype.format = function(format)       
{
	var o = {        
		"M+" : this.getMonth()+1, //month        
		"d+" : this.getDate(),    //day        
		"h+" : this.getHours(),   //hour        
		"m+" : this.getMinutes(), //minute        
		"s+" : this.getSeconds(), //second        
		"q+" : Math.floor((this.getMonth()+3)/3),  //quarter        
		"S+" : this.getMilliseconds() //millisecond        
	}        
	if(/(y+)/.test(format)) 
		format=format.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));        
	for(var k in o)
	{
		if(new RegExp("("+ k +")").test(format))
		{
			var _time = RegExp.$1;
			if(2 === _time.length)
			{
				_time = ("00"+ o[k]).substr((""+ o[k]).length);
			}
			else if(3 === _time.length)
			{
				_time = ("000"+ o[k]).substr((""+ o[k]).length);
			}

			format = format.replace(RegExp.$1, _time);
		}
	}
	return format;       
}

// FileUtil
// Copyright © Huawei Technologies Co., Ltd. 2014. All rights reserved.

var FileUtil = function()
{
	var _fo = null;	//file object
	
	var _config = {
		module: 'espacemedia_teller',	//module name
		logDir: 'C:/eMedia'				//log path
	}
	
	// !function init(private function)
	function _init()
	{
		var fso = new ActiveXObject("Scripting.FileSystemObject");
		if (null===fso || undefined===fso)
		{
			return;
		}
		//if log dir not exist, mkdir
		if (!_mkdir(fso,_config.logDir) )
		{
			return;
		}
		
		//open file
		var _sFilePath = _getFilePath();
		if (fso.FileExists(_sFilePath) )
		{
			_fo = fso.OpenTextFile(_sFilePath, 8);
		}
		else
		{
			_fo = fso.CreateTextFile(_sFilePath, true);
		}
	}
	
	// !function mkdir(private function)
	function _mkdir(fso, sDirPath)
	{
		if (fso.FolderExists(sDirPath) )
		{
			return true;
		}
		
		var dro = null;
		try
		{
			dro = fso.CreateFolder(sDirPath);
		}
		catch(e)
		{
			dro = null;
		}
		
		return (dro!=null);
	}
	
	// !function get log file path(private function)
	function _getFilePath()
	{
		var _sLogPath = _config.logDir;
		_sLogPath = _sLogPath.replace(/\\/g, '/');
		_sLogPath = _sLogPath.replace(/\/\//g, '/');
		return _sLogPath+'/'+_config.module+_formatDate()+ ".log";
	}
	
	// !function format date yyyymmdd(private function)
	function _formatDate()
	{
		var _date = new Date();
		
		return _date.format(Date.DAY_FORMAT);
	}
	
	// !function whether object is null(private function)
	function _isNull(object)
	{
		return (null===object || undefined===object)
	}
	
	// !function trim
	function _trimLog(sLog)
	{
		var _sLogInfo = sLog.replace(/\n/g,'');
		return _sLogInfo.replace(/(^\s*)|(\s*$)/g,"");
	}

	// !function format log message(private function)
	function _formatLog(loglevel,name,logType,sLog)
	{
		var _log = '['+ new Date().format(Date.DATETIME_FORMAT) +']';
		_log +='['+ loglevel +']' + '['+name+']' + '[' + logType + ']' + '[' + _trimLog(sLog) + ']';
		
		return _log;
	}
	return {
		// !function init
		init: function()
		{
			_init();
		},
		// !function
		// desc: write log
		// params:
		// [IN] loglevel : log level
		// [IN] name : function or event name
		// [IN] logType : log type
		// [IN] sLog : log content
		// return : void
		writeLog: function(loglevel, name,logType, sLog)
		{
			if (_isNull(_fo) )
			{
				return;
			}
			_fo.WriteLine(_formatLog(loglevel,name,logType,sLog) );
		},
		// !function custome log dir and module name
		setConfig: function(config)
		{
			if (_isNull(config) )
			{
				return;
			}
			if(!_isNull(config.logDir) )
			{
				_config.logDir = config.logDir
			}
			if(!_isNull(config.module) )
			{
				_config.module = config.module
			}
		},
		// !function close file stream
		close: function()
		{
			if (_isNull(_fo) )
			{
				return;
			}
			_fo.Close();
			_fo = null;
		}
		
	};
}();

//log type
FileUtil.LogType = {
	Function: 'function',
	Event: 'event'
};

//log level
FileUtil.LogLevel = {
	DEBUG: 'DEBUG',
	INFO: 'INFO',
	WARN: 'WARN',
	ERROR: 'ERROR'
};